/*
* mmc-hercules.h
*
*  Created on: Oct 4, 2015
*      Author: Jan
*/


#ifndef FATFS_PORT_MMC_HERCULES_H_
#define FATFS_PORT_MMC_HERCULES_H_


void mmcSelectSpi(gioPORT_t *port, spiBASE_t *reg);


#endif /* FATFS_PORT_MMC_HERCULES_H_ */
